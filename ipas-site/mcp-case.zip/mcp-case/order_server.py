"""
order_server.py — 訂單與退款 MCP Server（iPAS 中級 MCP 案例）

把公司的「訂單系統」包成一個 MCP Server，提供三種能力：
  - Tools     ：模型可呼叫的動作（查訂單、查物流、申請退款）
  - Resources ：App 可讀取的資料（退款政策文件、單筆訂單）
  - Prompts   ：使用者可挑選的範本（客訴回覆範本）

執行環境：Python 3.10+、pip install "mcp>=2"
（若使用 mcp 1.x，把第一個 import 換成 from mcp.server.fastmcp import FastMCP，
  並把 MCPServer 改成 FastMCP，其餘寫法相同）
"""
import logging
import sys
import uuid
from datetime import date

from mcp.server.mcpserver import MCPServer
from mcp.server.mcpserver.exceptions import ToolError
from mcp.types import ToolAnnotations

# ------------------------------------------------------------
# 1. 建立 Server：名稱與 instructions 會在初始化時告訴 Client
# ------------------------------------------------------------
mcp = MCPServer(
    name="order-system",
    instructions="Cloud X Berry 商店的訂單系統。查詢訂單後再決定是否退款；"
                 "退款金額超過 3,000 元必須由主管核准。",
)

# stdio 模式下 stdout 專門傳 JSON-RPC 訊息，任何 print 都會弄壞協定；
# 日誌一律寫到 stderr（Host 會收集成 Server 日誌）
logging.basicConfig(stream=sys.stderr, level=logging.INFO, format="%(asctime)s %(message)s")
log = logging.getLogger("order-system")

# 模擬後端資料庫（實務上這裡會呼叫公司原本的 REST API 或資料庫）
ORDERS = {
    "4471": {"customer": "C001", "item": "果汁機", "amount": 2490, "sale_item": True,
             "delivered": "2026-11-05", "status": "delivered"},
    "4480": {"customer": "C002", "item": "空氣清淨機", "amount": 8900, "sale_item": False,
             "delivered": "2026-11-02", "status": "delivered"},
    "4492": {"customer": "C001", "item": "電動牙刷", "amount": 1290, "sale_item": False,
             "delivered": None, "status": "shipping"},
}
REFUND_LIMIT = 3000          # 自動退款上限（業務規則寫在程式碼，不靠提示詞）
ISSUED: dict[str, str] = {}  # 冪等鍵 → 退款單號，避免重試造成重複退款


# ------------------------------------------------------------
# 2. Tools：模型決定何時呼叫。函式簽名與 docstring 會自動轉成
#    name / description / inputSchema（JSON Schema）
# ------------------------------------------------------------
@mcp.tool(annotations=ToolAnnotations(read_only_hint=True))
def lookup_order(order_id: str) -> dict:
    """依訂單編號查詢訂單內容、金額、是否為特價品與配送狀態。"""
    order = ORDERS.get(order_id)
    if order is None:
        raise ToolError(f"找不到訂單 {order_id}")   # 錯誤以簡短訊息回傳給模型
    return {"order_id": order_id, **order}


@mcp.tool(annotations=ToolAnnotations(read_only_hint=True))
def check_shipping(order_id: str) -> str:
    """查詢訂單目前的物流狀態。"""
    order = ORDERS.get(order_id)
    if order is None:
        raise ToolError(f"找不到訂單 {order_id}")
    if order["status"] == "delivered":
        return f"已於 {order['delivered']} 送達"
    return "配送中，預計 2 個工作天內送達"


@mcp.tool(annotations=ToolAnnotations(destructive_hint=True, idempotent_hint=True))
def issue_refund(order_id: str, amount: int, reason: str, idempotency_key: str) -> dict:
    """對已送達的訂單申請退款。amount 不可超過訂單金額；
    idempotency_key 為每次退款請求的唯一值，重試時請沿用同一個值。"""
    # (a) 冪等：同一個 key 重送，直接回傳上次結果，不會退兩次
    if idempotency_key in ISSUED:
        return {"status": "already_processed", "refund_id": ISSUED[idempotency_key]}

    # (b) 驗證輸入值是否合理
    order = ORDERS.get(order_id)
    if order is None:
        raise ToolError(f"找不到訂單 {order_id}")
    if order["status"] != "delivered":
        raise ToolError("訂單尚未送達，不能退款")
    if not 0 < amount <= order["amount"]:
        raise ToolError(f"退款金額必須介於 1 到 {order['amount']} 元")

    # (c) 業務規則：超過上限不執行，改為送審（human-in-the-loop）
    if amount > REFUND_LIMIT:
        log.info("訂單 %s 退款 %s 元超過上限，已轉主管核准", order_id, amount)
        return {"status": "pending_approval",
                "message": f"金額超過 {REFUND_LIMIT} 元，已送主管核准，核准後才會退款"}

    # (d) 真正執行（實務上是呼叫金流系統 API）
    refund_id = "RF-" + uuid.uuid4().hex[:8].upper()
    ISSUED[idempotency_key] = refund_id
    order["status"] = "refunded"
    log.info("已退款 %s 元，單號 %s，原因：%s", amount, refund_id, reason)   # 稽核紀錄
    return {"status": "refunded", "refund_id": refund_id, "amount": amount}


# ------------------------------------------------------------
# 3. Resources：由 App 決定何時讀取，用 URI 識別，適合放文件與資料
# ------------------------------------------------------------
@mcp.resource("policy://refund", mime_type="text/markdown")
def refund_policy() -> str:
    """退款政策（第 4 版）"""
    return ("# 退款政策 v4（2026-10-25 生效）\n"
            "- 到貨 30 天內可申請退款。\n"
            "- 特價品原則上不退，但到貨時已損壞者可全額退款。\n"
            f"- 單筆退款超過 {REFUND_LIMIT} 元需主管核准。\n")


@mcp.resource("orders://{order_id}")
def order_resource(order_id: str) -> dict:
    """單筆訂單資料（資源範本：URI 中的 {order_id} 是參數）"""
    return ORDERS.get(order_id, {})


# ------------------------------------------------------------
# 4. Prompts：由使用者挑選的範本，回傳要送給模型的訊息
# ------------------------------------------------------------
@mcp.prompt()
def damaged_item_reply(order_id: str, customer_name: str) -> str:
    """處理「商品到貨損壞」客訴的標準流程範本"""
    return (f"顧客 {customer_name} 反映訂單 {order_id} 到貨損壞。請依序：\n"
            "1. 呼叫 lookup_order 確認訂單與到貨日；\n"
            "2. 讀取 policy://refund 確認規定；\n"
            "3. 符合規定才呼叫 issue_refund，並用禮貌、簡短的語氣回覆顧客。\n"
            f"今天日期：{date.today().isoformat()}")


if __name__ == "__main__":
    # stdio：Server 由 Host 以子程序啟動，透過標準輸入／輸出交換 JSON-RPC 訊息
    # 遠端部署可改成 mcp.run(transport="streamable-http")
    mcp.run()
