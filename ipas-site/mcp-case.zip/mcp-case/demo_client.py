"""
demo_client.py — 模擬 Host 內的 MCP Client，連線到 order_server.py

實際產品中，Host（例如 Claude Desktop、IDE 的 AI 助理）會：
  1. 啟動 Server 並完成初始化握手
  2. 把 tools/list 拿到的工具描述交給 LLM
  3. LLM 決定要呼叫哪個工具 → Client 送出 tools/call → 結果再交回 LLM
這支程式把「LLM 的決定」寫死，方便觀察每一步的請求與回應。
執行：python demo_client.py
"""
import asyncio
import json
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

# Host 用子程序啟動 Server；Server 的 stderr 日誌會直接顯示在終端機
SERVER = StdioServerParameters(command=sys.executable, args=["order_server.py"])


def show(title, obj):
    print(f"\n=== {title} ===")
    print(obj if isinstance(obj, str) else json.dumps(obj, ensure_ascii=False, indent=2))


def text_of(result):
    """取出工具回傳的文字內容；isError=True 代表工具執行失敗"""
    body = "\n".join(c.text for c in result.content if getattr(c, "text", None))
    return ("[錯誤] " if result.is_error else "") + body


async def main():
    async with stdio_client(SERVER) as (read, write):
        async with ClientSession(read, write) as session:
            # 1) 初始化：交換協定版本與雙方能力
            init = await session.initialize()
            show("1. initialize", {"server": init.server_info.name,
                                   "protocol": init.protocol_version,
                                   "instructions": init.instructions})

            # 2) 探索：列出工具、資源、資源範本、提示範本
            tools = await session.list_tools()
            show("2a. tools/list", [{"name": t.name,
                                     "description": t.description,
                                     "required": t.input_schema.get("required"),
                                     "annotations": t.annotations.model_dump(exclude_none=True)
                                     if t.annotations else None} for t in tools.tools])
            res = await session.list_resources()
            tpl = await session.list_resource_templates()
            prm = await session.list_prompts()
            show("2b. resources / templates / prompts", {
                "resources": [str(r.uri) for r in res.resources],
                "templates": [t.uri_template for t in tpl.resource_templates],
                "prompts": [p.name for p in prm.prompts]})

            # 3) 讀取資源：App 把政策文件放進上下文
            policy = await session.read_resource("policy://refund")
            show("3. resources/read policy://refund", policy.contents[0].text)

            # 4) 取得提示範本：使用者在介面上選了「到貨損壞」範本
            p = await session.get_prompt("damaged_item_reply",
                                         {"order_id": "4471", "customer_name": "王小姐"})
            show("4. prompts/get damaged_item_reply", p.messages[0].content.text)

            # 5) 模型決定呼叫工具：先查訂單、再查物流
            r = await session.call_tool("lookup_order", {"order_id": "4471"})
            show("5a. tools/call lookup_order", text_of(r))
            r = await session.call_tool("check_shipping", {"order_id": "4471"})
            show("5b. tools/call check_shipping", text_of(r))

            # 6) 退款：同一個冪等鍵送兩次，模擬逾時後重試
            args = {"order_id": "4471", "amount": 2490, "reason": "到貨損壞",
                    "idempotency_key": "req-4471-001"}
            r = await session.call_tool("issue_refund", args)
            show("6a. tools/call issue_refund", text_of(r))
            r = await session.call_tool("issue_refund", args)
            show("6b. 重試（同一個 idempotency_key）", text_of(r))

            # 7) 超過上限：不執行，轉人工核准
            r = await session.call_tool("issue_refund", {
                "order_id": "4480", "amount": 8900, "reason": "不喜歡",
                "idempotency_key": "req-4480-001"})
            show("7. 超過 3,000 元上限", text_of(r))

            # 8) 錯誤處理：訂單不存在、金額不合理
            r = await session.call_tool("lookup_order", {"order_id": "9999"})
            show("8a. 訂單不存在", text_of(r))
            r = await session.call_tool("issue_refund", {
                "order_id": "4492", "amount": 1290, "reason": "等太久",
                "idempotency_key": "req-4492-001"})
            show("8b. 尚未送達", text_of(r))


if __name__ == "__main__":
    asyncio.run(main())
