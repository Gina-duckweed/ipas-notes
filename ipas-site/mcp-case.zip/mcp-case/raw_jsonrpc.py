"""
raw_jsonrpc.py — 不用 SDK，直接用 JSON-RPC 2.0 和 MCP Server 對話
用來看清楚線路上實際傳了什麼：stdio 傳輸是一行一個 JSON 訊息。
執行：python raw_jsonrpc.py
"""
import json
import subprocess
import sys

proc = subprocess.Popen([sys.executable, "order_server.py"], stdin=subprocess.PIPE,
                        stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True,
                        encoding="utf-8")


def send(msg):
    print(">>>", json.dumps(msg, ensure_ascii=False))
    proc.stdin.write(json.dumps(msg) + "\n")
    proc.stdin.flush()


def recv():
    line = proc.stdout.readline()
    msg = json.loads(line)
    print("<<<", json.dumps(msg, ensure_ascii=False)[:600])
    return msg


# 1. 初始化請求（有 id → 需要回應）
send({"jsonrpc": "2.0", "id": 1, "method": "initialize",
      "params": {"protocolVersion": "2025-11-25", "capabilities": {},
                 "clientInfo": {"name": "raw-client", "version": "0.1"}}})
recv()
# 2. 初始化完成通知（沒有 id → 通知，不需回應）
send({"jsonrpc": "2.0", "method": "notifications/initialized"})
# 3. 列出工具
send({"jsonrpc": "2.0", "id": 2, "method": "tools/list"})
recv()
# 4. 呼叫工具
send({"jsonrpc": "2.0", "id": 3, "method": "tools/call",
      "params": {"name": "check_shipping", "arguments": {"order_id": "4471"}}})
recv()
# 5. 呼叫不存在的訂單 → isError: true（工具錯誤，不是協定錯誤）
send({"jsonrpc": "2.0", "id": 4, "method": "tools/call",
      "params": {"name": "lookup_order", "arguments": {"order_id": "9999"}}})
recv()
# 6. 呼叫不存在的方法 → JSON-RPC error（協定錯誤）
send({"jsonrpc": "2.0", "id": 5, "method": "orders/delete", "params": {}})
recv()
proc.terminate()
